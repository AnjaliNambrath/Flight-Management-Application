var flights =[];

// var username = require("./loginscript")
window.onload = function(){
    const accessT = localStorage.getItem('token')
    if(!accessT){
        location.href = "/userlogin.html"
        return;
    }
    // getName()
    
    //get user fname and lname
    // userName = fname+" "+lname
}

// function getUserName(){
//     var ttp = new XMLHttpRequest();
//     ttp.onreadystatechange = function(){
//         if(this.readyState==4){
//             if(this.status==200){
//                 var details = JSON.parse(this.responseText);
//                 getName(details)
//             }
//         }
//     }
//     ttp.open("GET","http://localhost:5000/getFullName",true)
//     // xxhttp.setRequestHeader("Content-Type","application/json")
//     ttp.send()
//     event.preventDefault();
// }

// function getName(){
//     const accessTok = localStorage.getItem('token')
//     console.log("TTT",JSON.parse(accessTok));
//     var xxhttp = new XMLHttpRequest();
//     xxhttp.onreadystatechange = function(){
//         if(this.readyState==4){
//             if(this.status==200){
//                 // console.log("NAMEEE",this.responseText);
//                 User1=this.responseText;
//                 console.log("FROM ME",User1);
//                 localStorage.setItem('Fullname',User1)               
//             }
//         }
//     }
//     xxhttp.open("GET","http://localhost:5000/getOnlyName",true)
//     // xxhttp.setRequestHeader("Content-Type","application/json")
//     xxhttp.setRequestHeader('Authorization1',JSON.parse(accessTok))
//     xxhttp.send()
//     event.preventDefault();

// }
var USERNAME = localStorage.getItem('Fullname')
console.log("FROM OUTSIDE",USERNAME);
function logout(){
    localStorage.removeItem('token')
    location.href = "/userlogin.html"
}
// window.onload=getflights();
function display(src,des) {
    console.log("Display is called!!!");

    let content=`<div class='table'> <div class='user-header'>
    <span class='headcell'>Flight Number</span> 
    <span class='headcell'>Source</span>
     <span class='headcell'>Destination</span> 
     <span class='headcell'>Arrival Time</span> 
     <span class='headcell'>Departure Time</span>
     <span class='headcell'>Travel Date</span>
     <span class='headcell'>Price</span>
     <span class='headcell'>Booking</span>
     </div>`;

    //  var content = `<h3>Flights Available</h3><table border>
    //  <tr>
    //     <th border>flight_number</th>
    //      <th border >Source</th>
    //      <th border >Destination</th>
    //      <th border >Arrival Time</th>
    //      <th border>Departure_Time</th>
    //      <th border>travel_date</th>
    //      <th border >cost</th>
    //  </tr>`;
 

 console.log("SOURCEEE",src);
 console.log("SOURCEEE",des);


     for (let i in flights) {
        
         var s=flights[i].source;
         var d=flights[i].destination;
         if(s===src && d===des){        
         content+=`<div class='user'>
         <span class='cell'><i class="bi bi-airplane"></i>&nbsp;&nbsp;${flights[i].flight_number}  </span> 
         <span class='cell'>${flights[i].source}</span> 
         <span class='cell'>${flights[i].destination}</span>
         <span class='cell'>${flights[i].arrival_Time}</span> 
         <span class='cell'>${flights[i].departure_Time}</span>
         <span class='cell'>${flights[i].travel_Date}</span>
         <span class='cell'>${flights[i].cost}</span>
         <button class="btn" onclick='addCustomer("${flights[i]._id}")'>BOOK</button>

          </div>`;
        //          content += `
        //  <tr><td>${flights[i].flight_number}</td>
        //   <td>${flights[i].source}</td>
        //   <td>${flights[i].destination}</td>
        //   <td>${flights[i].arrival_Time}</td>
        //   <td>${flights[i].departure_Time}</td>
        //   <td>${flights[i].travel_Date}</td>
        //   <td>${flights[i].cost}</td>
        //   <td>
        //   <button onclick='addCustomer("${flights[i]._id}")'>BOOK</button>
        //   <td></tr>`;
        }
     }
     event.preventDefault();
     document.getElementById('srchbtn').innerHTML = content+"</div></div>";
     
 }

 function getflights() {

    console.log("getFlights called!!!");

    var src=document.getElementById('source').value;
    var des=document.getElementById('destination').value;
    console.log("src,des:",src,des);
    var req1 = new XMLHttpRequest();
    const url="http://localhost:5000/searchflights";
    // ?source="+src+"&destination="+des;
    req1.open("GET",url , true);
    req1.send();

    req1.onreadystatechange = function () {
        if (req1.readyState === 4) {
            if (req1.status === 200) {
                event.preventDefault();
                flights = JSON.parse(req1.responseText);
                console.log(flights);
                display(src,des);
                //event.preventDefault();
            }
        }
    }
    event.preventDefault();
}

let flight_id=""

function addCustomer(id){
   let form= document.getElementById('book');
   form.style.display='block';
   flight_id=id;
// let display=""
    for(keys in flights){
        if(flights[keys]._id=== id){
            console.log("source:::",flights[keys].source)
            document.getElementById('flightNumber').value=flights[keys].flight_number;
            document.getElementById('txtsource').value=flights[keys].source;
          //  document.getElementById('source').value=source;
             document.getElementById('txtdestination').value=flights[keys].destination;
           // document.getElementById('destination').value=destination;
            document.getElementById('arrivalTime').value=flights[keys].arrival_Time;
            document.getElementById('departureTime').value=flights[keys].departure_Time;
           // document.getElementById('travelDate').value=flights[keys].travel_Date;
            document.getElementById('price').value=flights[keys].cost;



        }
    }

}
