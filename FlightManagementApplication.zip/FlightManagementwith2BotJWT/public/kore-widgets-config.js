// var username = require("./js/loginscript")
// import {username} from "./js/loginscript"

console.log("FROM KORE",USERNAME);
(function(KoreSDK){

    var KoreSDK=KoreSDK||{};

    var botOptionsWiz = {};
    botOptionsWiz.logLevel = 'debug';
    botOptionsWiz.koreAPIUrl = "https://bots.kore.ai";

    botOptionsWiz.JWTUrl = "PLEASE_ENTER_JWTURL_HERE";
    botOptionsWiz.userIdentity = 'anjalivnamrat@gmail.com';// Provide users email id here
   botOptionsWiz.botInfo = { name: "MphasisBot", "_id": "st-06820314-91bd-536d-98e9-60c97637c4b1", 
                    "customData":{"name":USERNAME}}; 
                        botOptionsWiz.clientId = "cs-40a60c18-dd2d-5c1e-84a1-1f7a0d048fab";
    botOptionsWiz.clientSecret = "PLEASE_ENTER_CLIENT_SECRET";

    var widgetsConfig = {
        botOptions: botOptionsWiz
    };
    
    KoreSDK.widgetsConfig=widgetsConfig
})(window.KoreSDK);