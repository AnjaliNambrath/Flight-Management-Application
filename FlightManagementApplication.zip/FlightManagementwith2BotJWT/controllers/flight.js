const flight = require('../models/flight')
const users = require('../models/userModel')
var jwtlib = require('jsonwebtoken');
exports.createFlight = async (req,res)=>{
    try{
        const addFlight = await flight.create(req.body)
        console.log("Flight Added Successfully");
        res.status(200).json(addFlight)
    }
    catch(error){
        console.error("Error")
        res.status(500).send("Error")
    }
}

exports.getAllFlight = async(req,res)=>{
    try{
        const getFlight = await flight.find({})
        res.send(getFlight)
    }
    catch(err){
    console.error('Error getting flight', err);
    res.status(500).send('Error getting flight');
  } 
}

exports.updateFlight = async (req, res) => {
  const cId = req.params._id;
  const updatedFlight = req.body;
    console.log(updatedFlight);
  try{
    const options={new:true}
    const updateByid= await flight.findByIdAndUpdate(cId,updatedFlight,options);
    res.send({message:"Flight Updated successfully",updatedvalues:updateByid})
  }catch(err){
    console.error('Error updating Flight', err);
      res.status(500).send('Error updating Flight');
  }
};

exports.deleteFlight = async (req, res) => {
  const flightId = req.params._id;
  try{
    const flightByid= await flight.findByIdAndDelete(flightId);
    res.send({message:'Flight deleted successfully',deletePayment:flightByid});
  }catch(err){
    console.error('Error deleting flight', err);
    res.status(500).send('Error deleting flight');
  } 
};

exports.generateJWTForOTTBot = async(req,res)=>{
  res.set( {
 'Content-Type': 'application/json',
 "Access-Control-Allow-Origin":"*",
 "Access-Control-Allow-Headers":"*",
 "Access-Control-Allow-methods":"*"});

 let t = req.get('authtok')

 var userId = getUserId(JSON.parse(t))
  
    const payload = {
       "iat": (new Date().getTime())/1000,
       "exp": (new Date().getTime())/1000+86400,
            "aud": "https://idproxy.kore.ai/authorize",
            "iss": "cs-40a60c18-dd2d-5c1e-84a1-1f7a0d048fab",
        "sub": userId
    }
    const secret = "anB6jI8YOAAAtavfZVHNPD/71/MWgnKAh5KfmrNl4Fs=";
    var token = jwtlib.sign(payload, secret);
    res.status(200).json({jwt:token})

}


exports.generateJWTForAdminBot = async(req,res)=>{
  res.set( {
 'Content-Type': 'application/json',
 "Access-Control-Allow-Origin":"*",
 "Access-Control-Allow-Headers":"*",
 "Access-Control-Allow-methods":"*"});

//  let t = req.get('auth')
//  userId = getUserId(t)
    const payload = {
       "iat": (new Date().getTime())/1000,
       "exp": (new Date().getTime())/1000+86400,
            "aud": "https://idproxy.kore.ai/authorize",
            "iss": "cs-a93582f2-8539-559a-9df5-8eb4dd16be39",
        "sub": "anjalivnamrat@gmail.com"
    }
    const secret = "B1yU0XbQtJktlQYMlWfCMkl8P8iIbzO61yz6+KvApa8=";
    var token = jwtlib.sign(payload, secret);
    res.status(200).json({jwt:token})

}

function getUserId(t){
  console.log("Token",t);
  let decodedToken = jwtlib.decode(t,{complete:true})
  return decodedToken.payload.email;
}


// exports.getUserDetails = async (req,res)=>{
//   try{
//       const sendUser = await users.find({})
//         res.send(sendUser)  

//     }
//     catch(err){
//     console.error('Error getting user', err);
//     res.status(500).send('Error getting user');
//   }
// }

exports.getEmail = async (req,res)=>{
  try{
        var tt = req.header('Authorization1');
        // console.log("BACKTOKEN",tt);
        let decodedToke = jwtlib.decode(tt,{complete:true})
      res.send(decodedToke.payload.fullName);
    }
    catch(err){
    console.error('Error getting user', err);
    res.status(500).send('Error getting user');
  }
}